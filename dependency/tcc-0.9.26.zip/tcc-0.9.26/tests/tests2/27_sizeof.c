#include <stdio.h>

int main()
{
   char a;
   int b;
   double c;

   printf("%d\n", sizeof(a));
   printf("%d\n", sizeof(b));
   printf("%d\n", sizeof(c));

   return 0;
}

/* vim: set expandtab ts=4 sw=3 sts=3 tw=80 :*/
